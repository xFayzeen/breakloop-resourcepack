#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ---- BreakLoop: animated text effects ----
const float BL_TAU = 6.2831853;

int bl_match(ivec3 c, out int k) {
    k = 0;
    if (c.r == 252 && c.b == 4 && c.g >= 128 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 1; }
    if (c.r == 248 && c.b == 40 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 2; }
    if (c.r == 204 && c.b == 252 && c.g < 128 && c.g % 4 == 0) { k = c.g / 4; return 3; }
    if (c.g == 212 && c.b == 252 && c.r < 128 && c.r % 4 == 0) { k = c.r / 4; return 4; }
    if (c.r == 236 && c.b == 128 && c.g < 128 && c.g % 4 == 0) { k = c.g / 4; return 5; }
    if (c.g == 220 && c.b == 60 && c.r < 128 && c.r % 4 == 0) { k = c.r / 4; return 6; }
    if (c.r == 148 && c.b == 152 && c.g >= 100 && c.g < 228 && c.g % 4 == 0) { k = (c.g - 100) / 4; return 7; }
    if (c.r == 180 && c.b == 8 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 8; }
    if (c.r == 244 && c.b == 40 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 9; }
    if (c.r == 104 && c.b == 248 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 10; }
    if (c.r == 252 && c.b == 20 && c.g >= 128 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 19; }
    if (c.r == 240 && c.b == 48 && c.g >= 32 && c.g < 160 && c.g % 4 == 0) { k = (c.g - 32) / 4; return 11; }
    if (c.r == 88 && c.b == 244 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 12; }
    if (c.g == 232 && c.b == 72 && c.r >= 32 && c.r < 160 && c.r % 4 == 0) { k = (c.r - 32) / 4; return 13; }
    if (c.g == 236 && c.b == 148 && c.r >= 0 && c.r < 128 && c.r % 4 == 0) { k = (c.r - 0) / 4; return 14; }
    if (c.r == 92 && c.b == 248 && c.g >= 100 && c.g < 228 && c.g % 4 == 0) { k = (c.g - 100) / 4; return 15; }
    if (c.r == 164 && c.b == 244 && c.g >= 48 && c.g < 176 && c.g % 4 == 0) { k = (c.g - 48) / 4; return 16; }
    if (c.g == 228 && c.b == 216 && c.r >= 0 && c.r < 128 && c.r % 4 == 0) { k = (c.r - 0) / 4; return 17; }
    if (c.r == 252 && c.b == 12 && c.g >= 128 && c.g < 256 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 18; }
    return 0;
}

// effect id (0 = none), letter index, drop shadow (color * 0.25)
int bl_decode(vec3 rgb, out int k, out float dim) {
    ivec3 c = ivec3(rgb * 255.0 + 0.5);
    dim = 1.0;
    int e = bl_match(c, k);
    if (e == 0 && c.r <= 63 && c.g <= 63 && c.b <= 63) {
        e = bl_match(c * 4, k);
        dim = 0.25;
    }
    return e;
}

// 1.0 = text in the world (hologram text displays): stronger gradient; 0.0 = GUI/chat
float bl_world = 0.0;

vec3 bl_shine(vec3 a, vec3 b, float period, float k, float t, float sharp) {
    float s = 0.5 + 0.5 * sin(BL_TAU * t / period - k * 0.5);
    if (bl_world > 0.5) {
        // push both ends apart (deeper base color, brighter highlight) and widen the highlight band
        vec3 d = b - a;
        a = clamp(a - d * 0.5, 0.0, 1.0);
        b = clamp(b + d * 0.25, 0.0, 1.0);
        sharp = max(1.0, sharp * 0.75);
    }
    return mix(a, b, pow(s, sharp));
}

// t = seconds (GameTime = fraction of a day, 1 day = 1200 s); periods divide 1200 -> no jump on wrap
vec3 bl_color(int e, float k, float t) {
    if (e == 1 || e == 19) return bl_shine(vec3(1.0, 0.667, 0.0), vec3(1.0, 0.96, 0.66), 2.0, k, t, 3.0);
    if (e == 2 || e == 9) return bl_shine(vec3(1.0, 0.23, 0.12), vec3(1.0, 0.66, 0.25), 3.0, k, t, 1.0);
    if (e == 3) return bl_shine(vec3(1.0, 0.333, 1.0), vec3(1.0, 0.78, 1.0), 2.5, k, t, 2.0);
    if (e == 4) return bl_shine(vec3(0.333, 1.0, 1.0), vec3(0.85, 1.0, 1.0), 2.5, k, t, 2.0);
    if (e == 5) {
        vec3 h = clamp(abs(fract(t / 4.0 - k * 0.07 + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
        return mix(vec3(1.0), h, bl_world > 0.5 ? 0.85 : 0.7);
    }
    if (e == 6) return bl_shine(vec3(0.333, 1.0, 0.333), vec3(0.75, 1.0, 0.7), 2.5, k, t, 2.0);
    if (e == 7) return bl_shine(vec3(0.5, 0.5, 0.53), vec3(1.0, 1.0, 1.0), 3.0, k, t, 3.0);
    if (e == 11) return bl_shine(vec3(0.85, 0.08, 0.08), vec3(1.0, 0.45, 0.45), 3.0, k, t, 1.5);
    if (e == 12) return bl_shine(vec3(0.33, 0.33, 1.0), vec3(0.65, 0.75, 1.0), 3.0, k, t, 1.5);
    if (e == 13) return bl_shine(vec3(0.33, 1.0, 0.33), vec3(0.75, 1.0, 0.7), 3.0, k, t, 1.5);
    if (e == 14) return bl_shine(vec3(0.0, 0.66, 0.35), vec3(0.36, 1.0, 0.62), 3.0, k, t, 1.5);
    if (e == 15) return bl_shine(vec3(0.18, 0.36, 1.0), vec3(0.44, 0.66, 1.0), 3.0, k, t, 1.5);
    if (e == 16) return bl_shine(vec3(0.48, 0.18, 0.97), vec3(0.78, 0.49, 1.0), 3.0, k, t, 1.5);
    if (e == 17) return bl_shine(vec3(0.08, 0.72, 0.79), vec3(0.3, 1.0, 0.95), 3.0, k, t, 1.5);
    if (e == 18) return bl_shine(vec3(1.0, 0.62, 0.0), vec3(1.0, 0.9, 0.35), 3.0, k, t, 1.5);
    if (e == 10) return bl_shine(vec3(0.27, 0.27, 0.9), vec3(0.6, 0.6, 1.0), 3.0, k, t, 2.0);
    return bl_shine(vec3(0.69, 0.37, 0.0), vec3(1.0, 0.75, 0.45), 3.0, k, t, 3.0);
}

// wave (legendary, silver, bronze, firewave): ~1 px in GUI, ~1.5 font pixels of a text display in the world
// + in the world only: leaderboard titles (epic, uncommon, earned, gold)
vec3 bl_wave(vec3 pos, int e, float k, float t, bool gui) {
    bool w0 = e == 1 || e == 7 || e == 8 || e == 9;
    bool w1 = !gui && (e == 3 || e == 6 || e == 10 || e == 19);
    if (!w0 && !w1) return pos;
    float w = sin(BL_TAU * t / 1.5 - k * 0.6);
    return pos + vec3(0.0, gui ? w : w * 0.0375, 0.0);
}

void main() {
    int blK;
    float blDim;
    int blE = bl_decode(Color.rgb, blK, blDim);
    float blT = GameTime * 1200.0;
    vec3 pos = Position;
    vec4 col = Color;
    if (blE != 0) {
        bl_world = (ProjMat[3][3] != 0.0) ? 0.0 : 1.0;
        pos = bl_wave(Position, blE, float(blK), blT, ProjMat[3][3] != 0.0);
        col = vec4(bl_color(blE, float(blK), blT) * blDim, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = ProjMat[3][3] != 0.0 ? col : col * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
