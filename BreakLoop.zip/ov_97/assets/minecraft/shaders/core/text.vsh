#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
const bool BL_GUI = true;
#else
const bool BL_GUI = false;
#endif

// ---- BreakLoop: animated text effects ----
const float BL_TAU = 6.2831853;

int bl_match(ivec3 c, out int k) {
    k = 0;
    if (c.r == 252 && c.b == 4 && c.g >= 128 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 1; }
    if (c.r == 248 && c.b == 40 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 2; }
    if (c.r == 204 && c.b == 252 && c.g < 128 && c.g % 4 == 0) { k = c.g / 4; return 3; }
    if (c.g == 212 && c.b == 252 && c.r < 128 && c.r % 4 == 0) { k = c.r / 4; return 4; }
    if (c.r == 236 && c.b == 128 && c.g < 128 && c.g % 4 == 0) { k = c.g / 4; return 5; }
    if (c.g == 220 && c.b == 60 && c.r < 128 && c.r % 4 == 0) { k = c.r / 4; return 6; }
    if (c.r == 148 && c.b == 152 && c.g >= 100 && c.g < 228 && c.g % 4 == 0) { k = (c.g - 100) / 4; return 7; }
    if (c.r == 180 && c.b == 8 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 8; }
    if (c.r == 244 && c.b == 40 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 9; }
    if (c.r == 104 && c.b == 248 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 10; }
    if (c.r == 252 && c.b == 20 && c.g >= 128 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 19; }
    if (c.r == 168 && c.b == 252 && c.g < 128 && c.g % 4 == 0) { k = c.g / 4; return 20; }
    if (c.r == 232 && c.b == 72 && c.g >= 128 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 21; }
    if (c.r == 228 && c.b == 44 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 22; }
    if (c.r == 240 && c.b == 48 && c.g >= 32 && c.g < 160 && c.g % 4 == 0) { k = (c.g - 32) / 4; return 11; }
    if (c.r == 88 && c.b == 244 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 12; }
    if (c.g == 232 && c.b == 72 && c.r >= 32 && c.r < 160 && c.r % 4 == 0) { k = (c.r - 32) / 4; return 13; }
    if (c.g == 236 && c.b == 148 && c.r >= 0 && c.r < 128 && c.r % 4 == 0) { k = (c.r - 0) / 4; return 14; }
    if (c.r == 92 && c.b == 248 && c.g >= 100 && c.g < 228 && c.g % 4 == 0) { k = (c.g - 100) / 4; return 15; }
    if (c.r == 164 && c.b == 244 && c.g >= 48 && c.g < 176 && c.g % 4 == 0) { k = (c.g - 48) / 4; return 16; }
    if (c.g == 228 && c.b == 216 && c.r >= 0 && c.r < 128 && c.r % 4 == 0) { k = (c.r - 0) / 4; return 17; }
    if (c.r == 252 && c.b == 12 && c.g >= 128 && c.g < 256 && c.g % 4 == 0) { k = (c.g - 128) / 4; return 18; }
    if (c.r == 200 && c.b == 200 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 30; }
    if (c.r == 196 && c.b == 196 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 31; }
    if (c.r == 192 && c.b == 192 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 32; }
    if (c.r == 188 && c.b == 188 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 33; }
    if (c.r == 184 && c.b == 184 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 34; }
    if (c.r == 176 && c.b == 176 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 35; }
    if (c.r == 172 && c.b == 172 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 36; }
    if (c.r == 160 && c.b == 160 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 37; }
    if (c.r == 156 && c.b == 156 && c.g >= 64 && c.g < 192 && c.g % 4 == 0) { k = (c.g - 64) / 4; return 38; }
    return 0;
}

// effect id (0 = none), letter index, drop shadow (color * 0.25)
int bl_decode(vec3 rgb, out int k, out float dim) {
    ivec3 c = ivec3(rgb * 255.0 + 0.5);
    dim = 1.0;
    int e = bl_match(c, k);
    if (e == 0 && c.r <= 63 && c.g <= 63 && c.b <= 63) {
        e = bl_match(c * 4, k);
        dim = 0.25;
    }
    return e;
}

// 1.0 = text in the world (hologram text displays): stronger gradient; 0.0 = GUI/chat
float bl_world = 0.0;

vec3 bl_shine(vec3 a, vec3 b, float period, float k, float t, float sharp) {
    // world text (holograms) uses the same gradient as GUI/chat - the old contrast boost
    // made crate titles look completely different from the key names in the inventory
    float s = 0.5 + 0.5 * sin(BL_TAU * t / period - k * 0.5);
    return mix(a, b, pow(s, sharp));
}

// t = seconds (GameTime = fraction of a day, 1 day = 1200 s); periods divide 1200 -> no jump on wrap
vec3 bl_color(int e, float k, float t) {
    if (e == 1 || e == 19) return bl_shine(vec3(1.0, 0.667, 0.0), vec3(1.0, 0.96, 0.66), 2.0, k, t, 3.0);
    if (e == 2 || e == 9) return bl_shine(vec3(1.0, 0.23, 0.12), vec3(1.0, 0.66, 0.25), 3.0, k, t, 1.0);
    if (e == 3) return bl_shine(vec3(1.0, 0.333, 1.0), vec3(1.0, 0.78, 1.0), 2.5, k, t, 2.0);
    if (e == 4) return bl_shine(vec3(0.333, 1.0, 1.0), vec3(0.85, 1.0, 1.0), 2.5, k, t, 2.0);
    if (e == 5) {
        vec3 h = clamp(abs(fract(t / 4.0 - k * 0.07 + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
        return mix(vec3(1.0), h, bl_world > 0.5 ? 0.85 : 0.7);
    }
    if (e == 6) return bl_shine(vec3(0.333, 1.0, 0.333), vec3(0.75, 1.0, 0.7), 2.5, k, t, 2.0);
    if (e == 7) return bl_shine(vec3(0.5, 0.5, 0.53), vec3(1.0, 1.0, 1.0), 3.0, k, t, 3.0);
    if (e == 11) return bl_shine(vec3(0.85, 0.08, 0.08), vec3(1.0, 0.45, 0.45), 3.0, k, t, 1.5);
    if (e == 12) return bl_shine(vec3(0.33, 0.33, 1.0), vec3(0.65, 0.75, 1.0), 3.0, k, t, 1.5);
    if (e == 13) return bl_shine(vec3(0.33, 1.0, 0.33), vec3(0.75, 1.0, 0.7), 3.0, k, t, 1.5);
    if (e == 14) return bl_shine(vec3(0.0, 0.66, 0.35), vec3(0.36, 1.0, 0.62), 3.0, k, t, 1.5);
    if (e == 15) return bl_shine(vec3(0.18, 0.36, 1.0), vec3(0.44, 0.66, 1.0), 3.0, k, t, 1.5);
    if (e == 16) return bl_shine(vec3(0.48, 0.18, 0.97), vec3(0.78, 0.49, 1.0), 3.0, k, t, 1.5);
    if (e == 17) return bl_shine(vec3(0.08, 0.72, 0.79), vec3(0.3, 1.0, 0.95), 3.0, k, t, 1.5);
    if (e == 18) return bl_shine(vec3(1.0, 0.62, 0.0), vec3(1.0, 0.9, 0.35), 3.0, k, t, 1.5);
    if (e == 30) return bl_shine(vec3(0.239, 0.863, 0.353), vec3(0.582, 0.925, 0.644), 3.0, k, t, 2.0);
    if (e == 31) return bl_shine(vec3(0.910, 0.275, 0.227), vec3(0.950, 0.601, 0.575), 3.0, k, t, 2.0);
    if (e == 32) return bl_shine(vec3(1.000, 0.831, 0.231), vec3(1.000, 0.907, 0.577), 3.0, k, t, 2.0);
    if (e == 33) return bl_shine(vec3(0.651, 0.357, 1.000), vec3(0.808, 0.646, 1.000), 3.0, k, t, 2.0);
    if (e == 34) return bl_shine(vec3(1.000, 0.478, 0.176), vec3(1.000, 0.713, 0.547), 3.0, k, t, 2.0);
    if (e == 35) return bl_shine(vec3(0.239, 0.545, 1.000), vec3(0.582, 0.750, 1.000), 3.0, k, t, 2.0);
    if (e == 36) return bl_shine(vec3(0.910, 0.275, 0.227), vec3(0.950, 0.601, 0.575), 3.0, k, t, 2.0);
    if (e == 37) return bl_shine(vec3(0.345, 0.396, 0.949), vec3(0.640, 0.668, 0.972), 3.0, k, t, 2.0);
    if (e == 38) return bl_shine(vec3(0.247, 0.878, 1.000), vec3(0.586, 0.933, 1.000), 3.0, k, t, 2.0);
    if (e == 20) return bl_shine(vec3(0.65, 0.36, 1.0), vec3(0.86, 0.74, 1.0), 2.5, k, t, 2.0);
    if (e == 10) return bl_shine(vec3(0.27, 0.27, 0.9), vec3(0.6, 0.6, 1.0), 3.0, k, t, 2.0);
    if (e == 21) return bl_shine(vec3(0.9, 0.59, 0.27), vec3(1.0, 0.86, 0.62), 2.5, k, t, 2.0);
    if (e == 22) return bl_shine(vec3(1.0, 0.376, 0.176), vec3(1.0, 0.72, 0.5), 3.0, k, t, 2.0);
    return bl_shine(vec3(0.69, 0.37, 0.0), vec3(1.0, 0.75, 0.45), 3.0, k, t, 3.0);
}

// wave (legendary, silver, bronze, firewave): ~1 px in GUI, ~1.5 font pixels of a text display in the world
// + in the world only: leaderboard titles (epic, uncommon, earned, gold)
vec3 bl_wave(vec3 pos, int e, float k, float t, bool gui) {
    bool w0 = e == 1 || e == 7 || e == 8 || e == 9 || e == 22;
    bool w1 = !gui && (e == 3 || e == 6 || e == 10 || e == 19 || e == 20);
    if (!w0 && !w1) return pos;
    float w = sin(BL_TAU * t / 1.5 - k * 0.6);
    return pos + vec3(0.0, gui ? w : w * 0.0375, 0.0);
}

void main() {
    int blK;
    float blDim;
    int blE = bl_decode(Color.rgb, blK, blDim);
    float blT = GameTime * 1200.0;
    vec3 pos = Position;
    vec4 col = Color;
    if (blE != 0) {
        bl_world = (BL_GUI) ? 0.0 : 1.0;
        pos = bl_wave(Position, blE, float(blK), blT, BL_GUI);
        col = vec4(bl_color(blE, float(blK), blT) * blDim, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = blE != 0 ? col : col * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = col;
#endif
    texCoord0 = UV0;
}
